<?php
include_once 'config.php';
//$id = $_GET['id'];
$id = filter_input (INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
if(!empty($id)){
    $sql = "DELETE FROM eventos WHERE id='$id'";
    $conn->query($sql);
    $conn->close();
    echo '<meta http-equiv="refresh" content="0;url=index.html?msg=1" >';
}else{
    
    

    
};

    