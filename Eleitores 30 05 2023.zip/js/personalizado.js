$(document).ready(function () {
    $('.phone-mask').inputmask('(99) 9999-9999');
    $('.cel-mask').inputmask('(99) [9]9999-9999');
    $('.cep_mask').inputmask('99999-999');
  });
  function checkPasswordMatch() {
    const password = document.getElementById("senha").value;
    const confirmPassword = document.getElementById("confirma-senha").value;
    const messageDiv = document.getElementById("senha-match-message");
  
    if (password === confirmPassword) {
      messageDiv.textContent = "";
      messageDiv.style.color = "green";
    } else {
      messageDiv.textContent = "Senhas não coincidem";
      messageDiv.style.color = "red";
    }
  }
  
  function buscarNomes() {
    var nome = document.getElementById("nome_eleitor").value;
    
    if (nome.length > 0) {
        // Enviar uma requisição AJAX para buscar os nomes correspondentes
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && xhr.status === 200) {
                var response = JSON.parse(xhr.responseText);
                exibirNomesSugeridos(response);
            }
        };
        xhr.open("GET", "buscar_nomes.php?nome=" + nome, true);
        xhr.send();
    } else {
        // Limpar a lista de nomes sugeridos
        document.getElementById("nomes-sugeridos").innerHTML = "";
    }
}

function exibirNomesSugeridos(nomes) {
    var ul = document.getElementById("nomes-sugeridos");
    ul.innerHTML = "";
    
    for (var i = 0; i < nomes.length; i++) {
        var li = document.createElement("li");
        li.textContent = nomes[i];
        li.onclick = function() {
            selecionarNome(this.textContent);
        };
        ul.appendChild(li);
    }
}

function selecionarNome(nome) {
    document.getElementById("nome_eleitor").value = nome;
    document.getElementById("nomes-sugeridos").innerHTML = "";
}

  $(document).ready(function () {
    $('#cep').blur(function () {
      var cep = $(this).val().replace(/\D/g, '');
      if (cep != '') {
        var url = 'https://viacep.com.br/ws/' + cep + '/json/';
        $.getJSON(url, function (data) {
          if (!('erro' in data)) {
            $('#endereco').val(data.logradouro + ', ' + data.bairro);
            $('#municipio').val(data.localidade);
            $('#estado').val(data.uf);
          }
        });
      }
    });
  });

  document.addEventListener('DOMContentLoaded', function () {
    var calendarEl = document.getElementById('calendar');

    var calendar = new FullCalendar.Calendar(calendarEl, {
        locale: 'pt-br',
        //initialDate: '2023-05-05',
        initialView: 'timeGridWeek',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek',
        },
        height: 'auto',
        navLinks: true,
        editable: true,
        eventLimit: true,
        selectable: true,
        selectMirror: true,
        nowIndicator: true,
        events: 'list_evento.php',
        
        

        eventResize: function(info) {
          $("#editar #titulo").val(info.event.title);
          $("#editar #cor").val(info.event.backgroundColor);
          $("#editar #contato").val(info.event.extendedProps.contato);
          $("#editar #obs").text(info.event.extendedProps.obs);
          $("#editar #fim").val(info.event.end.toLocaleString());
          $("#editar #inicio").val(info.event.start.toLocaleString());
          $("#editar #id").val(info.event.id);
          $("#editar").modal('show');
        },
      
      eventDrop: function(info) {
          $("#editar #titulo").val(info.event.title);
          $("#editar #cor").val(info.event.backgroundColor);
          $("#editar #contato").val(info.event.extendedProps.contato);
          $("#editar #obs").text(info.event.extendedProps.obs);
          $("#editar #fim").val(info.event.end.toLocaleString());
          $("#editar #inicio").val(info.event.start.toLocaleString());
          $("#editar #id").val(info.event.id);
          $("#editar").modal('show');
        },

      eventClick: function (info) {   
          $("#apagar_evento").attr("href", "proc_apagar_evento.php?id=" + info.event.id);
          $("#editar #titulo").val(info.event.title);
          $("#editar #cor").val(info.event.backgroundColor);
          $("#editar #contato").val(info.event.extendedProps.contato);
          $("#editar #obs").text(info.event.extendedProps.obs);
          $("#editar #fim").val(info.event.end.toLocaleString());
          $("#editar #inicio").val(info.event.start.toLocaleString());
          $("#editar #id").val(info.event.id);
          $("#editar").modal('show');
      },

      select: function (info) {
          $('#cadastrar #inicio').val(info.start.toLocaleString());
          $("#cadastrar #fim").val(info.end.toLocaleString());
          $("#cadastrar").modal("show");
      },
    });

    calendar.render();
})
