<?php
    define('HOST', 'localhost');
    define('USER', 'root');
    define('PASS', '');
    define('BASE', 'eleicao');


  // Cria a conexão
  $conn = new mysqli(HOST, USER, PASS, BASE);

